from flask import Flask, request, jsonify
from flask_cors import CORS
import subprocess
import os
import uuid
import tempfile
import shutil
from pathlib import Path

app = Flask(__name__)
CORS(app)  # Enable CORS for frontend access

# Create temporary directory for code compilation
TEMP_DIR = Path(tempfile.gettempdir()) / "openmp_compiler"
TEMP_DIR.mkdir(exist_ok=True)

def cleanup_old_files():
    """Clean up files older than 1 hour"""
    import time
    current_time = time.time()
    for item in TEMP_DIR.iterdir():
        if item.is_file() or item.is_dir():
            if current_time - item.stat().st_mtime > 3600:  # 1 hour
                try:
                    if item.is_file():
                        item.unlink()
                    else:
                        shutil.rmtree(item)
                except:
                    pass

@app.route('/compile', methods=['POST'])
def compile_code():
    try:
        data = request.json
        code = data.get('code', '')
        num_threads = data.get('threads', 4)
        
        if not code:
            return jsonify({'error': 'No code provided'}), 400
        
        # Generate unique ID for this compilation
        job_id = str(uuid.uuid4())
        job_dir = TEMP_DIR / job_id
        job_dir.mkdir()
        
        # Write code to file
        source_file = job_dir / "program.c"
        executable = job_dir / "program"
        
        with open(source_file, 'w') as f:
            f.write(code)
        
        # Compile with OpenMP
        compile_cmd = [
            'gcc',
            '-fopenmp',
            str(source_file),
            '-o',
            str(executable),
            '-lm'  # Link math library
        ]
        
        compile_result = subprocess.run(
            compile_cmd,
            capture_output=True,
            text=True,
            timeout=10
        )
        
        if compile_result.returncode != 0:
            # Compilation failed
            shutil.rmtree(job_dir)
            return jsonify({
                'success': False,
                'error': 'Compilation Error',
                'stderr': compile_result.stderr,
                'stdout': compile_result.stdout
            })
        
        # Run the compiled program
        env = os.environ.copy()
        env['OMP_NUM_THREADS'] = str(num_threads)
        
        run_result = subprocess.run(
            [str(executable)],
            capture_output=True,
            text=True,
            timeout=5,
            env=env
        )
        
        # Clean up
        shutil.rmtree(job_dir)
        cleanup_old_files()
        
        return jsonify({
            'success': True,
            'output': run_result.stdout,
            'stderr': run_result.stderr,
            'returncode': run_result.returncode
        })
        
    except subprocess.TimeoutExpired:
        if 'job_dir' in locals():
            shutil.rmtree(job_dir, ignore_errors=True)
        return jsonify({
            'success': False,
            'error': 'Timeout',
            'stderr': 'Program execution took too long (>5 seconds)'
        }), 408
        
    except Exception as e:
        if 'job_dir' in locals():
            shutil.rmtree(job_dir, ignore_errors=True)
        return jsonify({
            'success': False,
            'error': 'Internal Server Error',
            'stderr': str(e)
        }), 500

@app.route('/examples', methods=['GET'])
def get_examples():
    """Return example OpenMP programs"""
    examples = {
        'hello_world': '''#include <stdio.h>
#include <omp.h>

int main() {
    #pragma omp parallel
    {
        int thread_id = omp_get_thread_num();
        int total_threads = omp_get_num_threads();
        printf("Hello from thread %d of %d\\n", thread_id, total_threads);
    }
    return 0;
}''',
        'array_sum': '''#include <stdio.h>
#include <omp.h>

int main() {
    int n = 1000;
    int arr[1000];
    int sum = 0;
    
    // Initialize array
    for (int i = 0; i < n; i++) {
        arr[i] = i + 1;
    }
    
    // Parallel sum using reduction
    #pragma omp parallel for reduction(+:sum)
    for (int i = 0; i < n; i++) {
        sum += arr[i];
    }
    
    printf("Sum of 1 to %d = %d\\n", n, sum);
    printf("Expected: %d\\n", (n * (n + 1)) / 2);
    return 0;
}''',
        'private_vs_shared': '''#include <stdio.h>
#include <omp.h>

int main() {
    int shared_var = 0;
    int private_var = 100;
    
    printf("Before parallel region:\\n");
    printf("shared_var = %d, private_var = %d\\n\\n", shared_var, private_var);
    
    #pragma omp parallel num_threads(4) private(private_var) shared(shared_var)
    {
        int tid = omp_get_thread_num();
        private_var = tid * 10;  // Each thread has its own copy
        
        #pragma omp critical
        {
            shared_var += tid;  // All threads share this variable
            printf("Thread %d: private_var = %d, shared_var = %d\\n", 
                   tid, private_var, shared_var);
        }
    }
    
    printf("\\nAfter parallel region:\\n");
    printf("shared_var = %d, private_var = %d\\n", shared_var, private_var);
    return 0;
}''',
        'critical_section': '''#include <stdio.h>
#include <omp.h>

int main() {
    int counter = 0;
    
    printf("Without critical section (race condition):\\n");
    #pragma omp parallel for num_threads(4)
    for (int i = 0; i < 1000; i++) {
        counter++;  // Race condition!
    }
    printf("Counter = %d (should be 1000)\\n\\n", counter);
    
    counter = 0;
    printf("With critical section:\\n");
    #pragma omp parallel for num_threads(4)
    for (int i = 0; i < 1000; i++) {
        #pragma omp critical
        counter++;
    }
    printf("Counter = %d (correct!)\\n", counter);
    return 0;
}'''
    }
    return jsonify(examples)

@app.route('/health', methods=['GET'])
def health_check():
    """Check if OpenMP is available"""
    try:
        result = subprocess.run(
            ['gcc', '--version'],
            capture_output=True,
            text=True,
            timeout=5
        )
        return jsonify({
            'status': 'ok',
            'gcc_available': result.returncode == 0,
            'gcc_version': result.stdout.split('\n')[0] if result.returncode == 0 else None
        })
    except:
        return jsonify({'status': 'error', 'gcc_available': False}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
